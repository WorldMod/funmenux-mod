package com.funmenux.client.mixin;

import com.funmenux.client.FunMenuXClient;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Freelook: lets the rendered camera pan independently of the entity's
 * actual yaw/pitch, WITHOUT writing back to entity.setYaw()/setPitch().
 *
 * Important: this only changes what YOU see. The entity's real body/head
 * rotation — what other players see when they look at you, and what the
 * server uses for hit detection/raytracing — is untouched. This is a
 * cosmetic/cinematic camera, not an aim or reach modifier.
 */
@Mixin(Camera.class)
public abstract class CameraMixin {

    @Shadow protected abstract void setRotation(float yaw, float pitch);

    private float funmenux$freeYawOffset = 0f;
    private float funmenux$freePitchOffset = 0f;

    @Inject(method = "update", at = @At("TAIL"))
    private void funmenux$applyFreelook(net.minecraft.world.BlockView area, Entity focusedEntity,
                                         boolean thirdPerson, boolean inverseView, float tickDelta,
                                         CallbackInfo ci) {
        if (!FunMenuXClient.CONFIG.freelookEnabled) return;
        if (!FunMenuXClient.mc().options.sneakKey.isPressed()) return; // hold-to-freelook

        // Clamp offsets so the camera can't spin further than the configured
        // limits away from the entity's real facing.
        float maxYaw = FunMenuXClient.CONFIG.freelookMaxYawOffset;
        float maxPitch = FunMenuXClient.CONFIG.freelookMaxPitchOffset;
        funmenux$freeYawOffset = Math.max(-maxYaw, Math.min(maxYaw, funmenux$freeYawOffset));
        funmenux$freePitchOffset = Math.max(-maxPitch, Math.min(maxPitch, funmenux$freePitchOffset));

        Camera self = (Camera) (Object) this;
        this.setRotation(self.getYaw() + funmenux$freeYawOffset, self.getPitch() + funmenux$freePitchOffset);
    }

    // Mouse-delta hookup for the offsets above lives in a MouseMixin in a
    // full build (adds to funmenux$freeYawOffset/PitchOffset while the
    // freelook key is held, resets to 0 on release). Omitted here to keep
    // this file focused — see README section "Wiring the mouse".
}
