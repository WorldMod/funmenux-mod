package com.funmenux.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Draws current/max HP above hostile & passive mobs within range.
 *
 * Intentionally scoped to MobEntity only. PlayerEntity is explicitly
 * excluded — this overlay is a QoL feature for farming/exploring, not
 * a PvP information advantage. Do not widen the entity filter below
 * to include players.
 */
public class MobHealthRenderer {

    public static void render(WorldRenderContext context) {
        ModConfig cfg = FunMenuXClient.CONFIG;
        if (!cfg.mobHealthOverlayEnabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        double range = cfg.mobHealthOverlayRange;
        Box searchBox = client.player.getBoundingBox().expand(range);

        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        TextRenderer textRenderer = client.textRenderer;
        Vec3d camPos = context.camera().getPos();

        for (Entity entity : client.world.getEntitiesByClass(MobEntity.class, searchBox, e -> true)) {
            // Belt-and-braces: never render for players even if a future
            // refactor loosens the class filter above.
            if (entity instanceof PlayerEntity) continue;

            MobEntity mob = (MobEntity) entity;
            String label = String.format("%.0f / %.0f", mob.getHealth(), mob.getMaxHealth());

            double x = mob.getX() - camPos.x;
            double y = mob.getY() + mob.getHeight() + 0.5 - camPos.y;
            double z = mob.getZ() - camPos.z;

            matrices.push();
            matrices.translate(x, y, z);
            matrices.multiply(client.gameRenderer.getCamera().getRotation());
            matrices.scale(-0.025f, -0.025f, 0.025f);

            float textX = -textRenderer.getWidth(label) / 2.0f;
            textRenderer.draw(label, textX, 0, 0x55FF55, false,
                    matrices.peek().getPositionMatrix(), consumers,
                    net.minecraft.client.font.TextRenderer.TextLayerType.NORMAL,
                    0x40000000, 0xF000F0);

            matrices.pop();
        }
    }
}
