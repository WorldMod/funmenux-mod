package com.funmenux.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Persisted client-side settings. Everything here is cosmetic / QoL only —
 * no networking, no packet spoofing, nothing that touches other players' data.
 */
public class ModConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("funmenux.json");

    // Freelook camera
    public boolean freelookEnabled = true;
    public float freelookMaxYawOffset = 90.0f;
    public float freelookMaxPitchOffset = 60.0f;

    // Particles
    public boolean jumpParticlesEnabled = true;
    public boolean flightParticlesEnabled = true;
    public String jumpParticleType = "minecraft:cloud";
    public String flightParticleType = "minecraft:end_rod";

    // Mob HP overlay (mobs only — see README, players intentionally excluded)
    public boolean mobHealthOverlayEnabled = true;
    public float mobHealthOverlayRange = 32.0f;

    // Totem core animation speed multiplier (matches the resource pack's
    // flipbook texture — purely visual, read by ConfigScreen slider)
    public float totemAnimationSpeed = 1.0f;

    // Cosmetics
    public boolean trailsEnabled = true;
    public boolean chinaHatEnabled = true;

    public static ModConfig load() {
        if (Files.exists(PATH)) {
            try (Reader reader = Files.newBufferedReader(PATH)) {
                ModConfig cfg = GSON.fromJson(reader, ModConfig.class);
                if (cfg != null) return cfg;
            } catch (IOException e) {
                System.err.println("Failed to read funmenux.json, using defaults: " + e);
            }
        }
        return new ModConfig();
    }

    public void save() {
        try {
            Files.createDirectories(PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(PATH)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            System.err.println("Failed to save funmenux.json: " + e);
        }
    }
}
