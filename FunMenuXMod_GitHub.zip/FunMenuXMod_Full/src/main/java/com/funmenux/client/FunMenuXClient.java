package com.funmenux.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class FunMenuXClient implements ClientModInitializer {

    public static ModConfig CONFIG;

    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        CONFIG = ModConfig.load();

        // --- Right Shift opens the config screen ---
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.funmenux.openmenu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.funmenux"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ConfigScreen(null));
                }
            }
        });

        // --- Jump / elytra particles ---
        ClientTickEvents.END_CLIENT_TICK.register(ParticleHandler::onClientTick);

        // --- Mob HP overlay (mobs only, never players) ---
        WorldRenderEvents.AFTER_ENTITIES.register(MobHealthRenderer::render);

        // --- Trails behind player ---
        TrailsHandler.register();

        // --- China hat cosmetic ---
        WorldRenderEvents.AFTER_ENTITIES.register(ChinaHatRenderer::render);

        System.out.println("FunMenuX client init complete");
    }

    public static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }
}

