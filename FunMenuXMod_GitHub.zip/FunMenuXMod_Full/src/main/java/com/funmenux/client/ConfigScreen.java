package com.funmenux.client;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/**
 * Simple settings screen, opened via Right Shift (see FunMenuXClient).
 * Every option here is purely cosmetic/QoL — no reach, no aim assist,
 * no data about other players.
 */
public class ConfigScreen extends Screen {

    private final Screen parent;
    private final ModConfig cfg = FunMenuXClient.CONFIG;

    protected ConfigScreen(Screen parent) {
        super(Text.literal("FunMenuX Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int x = this.width / 2 - 100;
        int y = this.height / 2 - 70;
        int spacing = 24;

        this.addDrawableChild(ButtonWidget.builder(
                toggleText("Freelook camera", cfg.freelookEnabled),
                b -> {
                    cfg.freelookEnabled = !cfg.freelookEnabled;
                    b.setMessage(toggleText("Freelook camera", cfg.freelookEnabled));
                }).dimensions(x, y, 200, 20).build());
        y += spacing;

        this.addDrawableChild(ButtonWidget.builder(
                toggleText("Jump particles", cfg.jumpParticlesEnabled),
                b -> {
                    cfg.jumpParticlesEnabled = !cfg.jumpParticlesEnabled;
                    b.setMessage(toggleText("Jump particles", cfg.jumpParticlesEnabled));
                }).dimensions(x, y, 200, 20).build());
        y += spacing;

        this.addDrawableChild(ButtonWidget.builder(
                toggleText("Flight particles", cfg.flightParticlesEnabled),
                b -> {
                    cfg.flightParticlesEnabled = !cfg.flightParticlesEnabled;
                    b.setMessage(toggleText("Flight particles", cfg.flightParticlesEnabled));
                }).dimensions(x, y, 200, 20).build());
        y += spacing;

        this.addDrawableChild(ButtonWidget.builder(
                toggleText("Mob HP overlay", cfg.mobHealthOverlayEnabled),
                b -> {
                    cfg.mobHealthOverlayEnabled = !cfg.mobHealthOverlayEnabled;
                    b.setMessage(toggleText("Mob HP overlay", cfg.mobHealthOverlayEnabled));
                }).dimensions(x, y, 200, 20).build());
        y += spacing;

        this.addDrawableChild(ButtonWidget.builder(
                toggleText("Player trails", cfg.trailsEnabled),
                b -> {
                    cfg.trailsEnabled = !cfg.trailsEnabled;
                    b.setMessage(toggleText("Player trails", cfg.trailsEnabled));
                }).dimensions(x, y, 200, 20).build());
        y += spacing;

        this.addDrawableChild(ButtonWidget.builder(
                toggleText("China hat", cfg.chinaHatEnabled),
                b -> {
                    cfg.chinaHatEnabled = !cfg.chinaHatEnabled;
                    b.setMessage(toggleText("China hat", cfg.chinaHatEnabled));
                }).dimensions(x, y, 200, 20).build());
        y += spacing;

        this.addDrawableChild(new SliderWidget(x, y, 200, 20,
                Text.literal("Totem anim speed: " + String.format("%.1fx", cfg.totemAnimationSpeed)),
                (cfg.totemAnimationSpeed) / 3.0) {
            @Override
            protected void updateMessage() {
                setMessage(Text.literal("Totem anim speed: " + String.format("%.1fx", cfg.totemAnimationSpeed)));
            }

            @Override
            protected void applyValue() {
                cfg.totemAnimationSpeed = (float) (this.value * 3.0);
            }
        });
        y += spacing + 6;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> {
            cfg.save();
            this.close();
        }).dimensions(x, y, 200, 20).build());
    }

    private static Text toggleText(String label, boolean on) {
        return Text.literal(label + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void close() {
        cfg.save();
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
