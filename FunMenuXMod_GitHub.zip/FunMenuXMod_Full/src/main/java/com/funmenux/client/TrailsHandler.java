package com.funmenux.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/**
 * Draws particle trails behind the player when moving/running
 */
public class TrailsHandler {

    private static int trailCounter = 0;

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            if (!FunMenuXClient.CONFIG.trailsEnabled) return;

            trailCounter++;
            if (trailCounter < 3) return; // Spawn every 3 ticks
            trailCounter = 0;

            ClientPlayerEntity player = client.player;
            ClientWorld world = client.world;
            Vec3d pos = player.getPos();

            // Spawn particle trail
            world.addParticle(
                    ParticleTypes.END_ROD,
                    pos.x + (Math.random() - 0.5) * 0.5,
                    pos.y + 0.5,
                    pos.z + (Math.random() - 0.5) * 0.5,
                    0, 0.05, 0
            );
        });
    }
}
