# FunMenuX Fabric Mod (source, unbuilt)

Client-only QoL mod. Targets **Minecraft 1.16.5 / Fabric** (matches the resource pack's `pack_format 6`).

## Честно про риск на этой версии
`WorldRenderEvents` (класс, который использует `MobHealthRenderer`) я подтвердил
по документации Fabric API начиная с версии для 1.17 (0.34.8+1.17). Для
1.16.5 (fabric_version=0.42.0+1.16) он, скорее всего, тоже есть — модуль
`fabric-rendering-v1` существовал и раньше — но я не смог это проверить
компиляцией (нет сети). Если сборка упадёт на импорте
`net.fabricmc.fabric.api.client.rendering.v1.*` — это будет означать, что
класса нет в этой версии API, и `MobHealthRenderer` нужно переписать через
Mixin в `LivingEntityRenderer` вместо события Fabric API. Кинь мне текст
ошибки — сделаю это сразу.

## Что внутри
- `FunMenuXClient` — точка входа, регистрирует keybind (Right Shift) и хуки
- `ConfigScreen` — экран настроек, открывается по Right Shift
- `ModConfig` — сохраняется в `.minecraft/config/funmenux.json`
- `ParticleHandler` — частицы на прыжке и при полёте на элитрах
- `MobHealthRenderer` — HP над **мобами** (намеренно НЕ включает игроков — см. комментарий в файле)
- `mixin/CameraMixin` — фрилук-камера: меняет только то, что видишь ТЫ,
  не трогает реальные yaw/pitch сущности, значит на хитбоксы/PvP не влияет

## Чего не хватает, чтобы это заработало из коробки
1. **MouseMixin для фрилука.** Сейчас `CameraMixin` только клэмпит и
   применяет `freeYawOffset/freePitchOffset`, но ничего не крутит эти
   поля от мыши. Нужно добавить миксин на `Mouse.updateMouse()`, который,
   пока зажата кнопка фрилука, добавляет `dx/dy` в offset'ы вместо вызова
   `player.changeLookDirection()`. Я оставил это как TODO, а не написал
   вслепую, потому что тут легко случайно всё-таки завязать это на
   реальный yaw/pitch игрока — а именно этого просили избежать.
2. **Gradle wrapper.** Здесь нет `gradlew`/`gradle-wrapper.jar` (бинарник,
   его не кладут текстом). Один раз выполни `gradle wrapper` с любым
   локально установленным Gradle 8.x, дальше `./gradlew build` будет
   работать сам.

## Сборка
```
gradle wrapper          # один раз, если нет gradlew
./gradlew build          # jar появится в build/libs/funmenux-1.0.0.jar
```
Нужен JDK 17 и интернет (Loom качает Minecraft/Yarn/Fabric API).

## Установка
1. Fabric Loader + Fabric API для 1.20.1
2. `funmenux-1.0.0.jar` → `.minecraft/mods/`
3. Ресурспак — отдельно, из `FunMenuX_ResourcePack.zip`

## Почему тут нет HP игроков
См. обсуждение в чате: это ESP-функциональность, обычно запрещённая
правилами серверов. Оверлей ограничен `MobEntity` и явно исключает
`PlayerEntity` даже при случайном расширении фильтра.
