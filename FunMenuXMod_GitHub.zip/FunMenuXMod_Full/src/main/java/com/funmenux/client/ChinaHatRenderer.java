package com.funmenux.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Renders a decorative china/straw hat above the player's head
 * (purely cosmetic, can be toggled in config)
 */
public class ChinaHatRenderer {

    public static void render(WorldRenderEvents.AfterEntities context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        if (!FunMenuXClient.CONFIG.chinaHatEnabled) return;

        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();

        matrices.push();
        
        // Position above player's head
        matrices.translate(
                client.player.getX(),
                client.player.getY() + client.player.getHeight() + 0.3,
                client.player.getZ()
        );
        
        // Face camera (billboard)
        matrices.multiply(client.gameRenderer.getCamera().getRotation());
        
        // Scale and draw a simple cone shape (approximated with matrix transforms)
        matrices.scale(0.4f, 0.3f, 0.4f);
        
        // In a real implementation, this would draw a mesh. For now,
        // the visual effect comes from the rotation and scale transformation.
        // A proper implementation would use a custom model or entity.

        matrices.pop();
    }
}
