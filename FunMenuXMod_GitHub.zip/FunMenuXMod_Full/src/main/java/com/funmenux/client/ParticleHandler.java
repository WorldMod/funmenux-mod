package com.funmenux.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

public class ParticleHandler {

    private static boolean wasOnGround = true;

    public static void onClientTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null) return;

        ModConfig cfg = FunMenuXClient.CONFIG;

        boolean onGround = player.isOnGround();
        boolean justJumped = wasOnGround && !onGround && player.getVelocity().y > 0.1;
        wasOnGround = onGround;

        if (justJumped && cfg.jumpParticlesEnabled) {
            for (int i = 0; i < 8; i++) {
                double ox = (world.random.nextDouble() - 0.5) * player.getWidth();
                double oz = (world.random.nextDouble() - 0.5) * player.getWidth();
                world.addParticle(
                        ParticleTypes.CLOUD,
                        player.getX() + ox, player.getY() + 0.05, player.getZ() + oz,
                        0.0, 0.05, 0.0
                );
            }
        }

        if (player.isFallFlying() && cfg.flightParticlesEnabled) {
            Vec3d back = player.getRotationVector().multiply(-0.6);
            world.addParticle(
                    ParticleTypes.END_ROD,
                    player.getX() + back.x, player.getY() + 0.2 + back.y, player.getZ() + back.z,
                    0.0, 0.0, 0.0
            );
        }
    }
}
